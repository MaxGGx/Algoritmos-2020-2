Problema 1
La explicación acerca del algoritmo se puede hallar dentro del codigo del .py, utilizando como base la busqueda binaria

Consideraciones:
-Se asume que las entradas seran las correctas.
-Se asume que se ingresarán las listas de manera ordenada.

-Para los inputs estos los solicitará en el momento en que se inicie el programa.

Problema 2
Solucion implementada parcialmente, el algoritmo puede realizar las operaciones merge correctamente, como fue sugerido, junto a ello
puede calcular para los sub arreglos conformados luego de dichas operaciones, sin embargo, el problema se presenta para sub arreglos que no se encuentran dentro
de las que se forman con la operacion merge.

Consideraciones:
-Se considera que el usuario siempre ingresará inputs correctos siguiendo las liniamientos señalados en la tarea.
 
Para makefile:

Pregunta1
-Basta con escribir "python3 pregunta1.py" para ejecutar la pregunta 1 con entrada standard por consola manual.

Pregunta 2
-Basta con escribir "make" o "make all" en la consola para ejecutar la pregunta 2 y para el input, este puede ser como "./a.out" para ingresar los valores manualmente o "./a.out < input.txt" para hacer uso del .txt con los inputs previamente colocados.
