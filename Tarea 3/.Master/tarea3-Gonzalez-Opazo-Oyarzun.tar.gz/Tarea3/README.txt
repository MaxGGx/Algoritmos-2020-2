@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@> Tarea 3 - Algoritmos <@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

Consideraciones:
-Dentro del código se puede hallar comentado la explicación hacia el funcionamiento del algoritmo.


Instrucciones de compilación:

Para poder ejecutar la pregunta 1, basta con colocar por consola:
-"py Pregunta1_Final.py" o "python3 Pregunta1_Final.py"

y luego se pueden ingresar los valores manualmente o copiando hacia la consola directamente.

